CS 251 grading scripts
=======

A set of scripts used to check for common errors and preformat the file used for grading ("cs251Grades.txt").
